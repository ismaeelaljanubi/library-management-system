setTimeout(() => {
  document.querySelectorAll(".alert").forEach(msg => {
    msg.style.opacity = "0";
    setTimeout(() => msg.remove(), 400);
  });
}, 4000);
function toggleMenu() {
  document.getElementById("dropdown").classList.toggle("show");
}

function showSection(id) {
  document.querySelectorAll(".section").forEach(sec => {
    sec.style.display = "none";
  });

  document.getElementById(id).style.display = "block";
  document.getElementById(id).scrollIntoView({ behavior: "smooth" });
}

setTimeout(() => {
  document.querySelectorAll(".alert").forEach(a => {
    a.style.opacity = "0";
    setTimeout(() => a.remove(), 400);
  });
}, 4000);
function showDetails(id) {
  const box = document.getElementById("details-" + id);
  box.style.display = box.style.display === "block" ? "none" : "block";
}

setTimeout(() => {
  document.querySelectorAll(".alert").forEach(a => {
    a.style.opacity = "0";
    setTimeout(() => a.remove(), 400);
  });
}, 4000);
function toggleDetails(bookId) {
  const details = document.getElementById("details-" + bookId);

  if (!details) return;

  if (details.style.display === "none" || details.style.display === "") {
    details.style.display = "block";
  } else {
    details.style.display = "none";
  }
}
function toggleBorrowedPanel() {
  const panel = document.getElementById("borrowedPanel");
  const toggleBtn = document.getElementById("borrowedToggle");

  if (panel.classList.contains("open")) {
    panel.classList.remove("open");
    toggleBtn.style.display = "block";
  } else {
    panel.classList.add("open");
    toggleBtn.style.display = "none";
  }
}