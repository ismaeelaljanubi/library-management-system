function toggleMenu() {
  document.getElementById("dropdown").classList.toggle("show");
}

function showSection(id) {
  document.querySelectorAll(".section").forEach(sec => {
    sec.style.display = "none";
  });
  document.getElementById(id).style.display = "block";
}

function filterBooks(categoryId) {
  document.querySelectorAll("#booksTable tr").forEach(row => {
    row.style.display =
      !categoryId || row.dataset.category === categoryId ? "" : "none";
  });
}

function filterEditBooks(categoryId) {
  document.querySelectorAll("#editBooks option").forEach(opt => {
    opt.style.display =
      !categoryId || opt.dataset.category === categoryId ? "" : "none";
  });
}