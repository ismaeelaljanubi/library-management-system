from flask import Blueprint, render_template, request, session, redirect, flash
from models import db
from models.book import Book
from models.category import Category
from models.borrowing import Borrowing
from models.rating import Rating
from datetime import date
from sqlalchemy import or_

user_bp = Blueprint("user", __name__)


def user_required():
    if "user_id" not in session:
        flash("يجب تسجيل الدخول أولاً", "error")
        return False
    return True

@user_bp.route("/user")
def user_page():
    if not user_required():
        return redirect("/")

    user_id = session["user_id"]
    q = request.args.get("q")

    
    if q:
        books = Book.query.join(Category).filter(
            or_(
            Book.title.like(f"%{q}%"),
            Category.name.like(f"%{q}%"),
            Book.serial_number.like(f"%{q}%")
        )
        ).all()

        if not books:
            flash("لا توجد نتائج مطابقة", "error")
    else:
       
        books = Book.query.order_by(Book.book_id.desc()).limit(6).all()

    user_borrowed_book_ids = {
        b.book_id for b in Borrowing.query.filter_by(
            user_id=user_id,
            status="borrowed"
        ).all()
    }

   
    rateable_book_ids = {
        b.book_id for b in Borrowing.query.filter_by(
            user_id=user_id,
            status="borrowed"
        ).all()
        if not Rating.query.filter_by(
            user_id=user_id,
            book_id=b.book_id
        ).first()
    }
    user_borrowing = Borrowing.query.filter_by(
        user_id=user_id,
        status="borrowed"
    ).all()
    return render_template(
    "user_page.html",
    books=books,
    user_borrowed_book_ids=user_borrowed_book_ids,
    rateable_book_ids=rateable_book_ids,
    user_borrowings=user_borrowing
    )



@user_bp.route("/user/borrow/<int:book_id>", methods=["POST"])
def borrow_book(book_id):
    if "user_id" not in session:
        flash("يجب تسجيل الدخول أولاً", "error")
        return redirect("/")

    user_id = session["user_id"]

    active_count = Borrowing.query.filter_by(
        user_id=user_id,
        status="borrowed"
    ).count()

    if active_count >= 3:
        flash("لا يمكن استعارة أكثر من 3 كتب", "error")
        return redirect("/user")

    book = Book.query.get(book_id)

    if not book or book.status != "avalible":
        flash("الكتاب غير متوفر حالياً", "error")
        return redirect("/user")

    borrowing = Borrowing(
        user_id=session["user_id"],
        book_id=book_id,
        borrow_date=date.today(),
        status="borrowed"
    )

    book.status = "borrowed"

    db.session.add(borrowing)
    db.session.commit()

    flash("تمت استعارة الكتاب بنجاح", "success")
    return redirect("/user")



@user_bp.route("/user/return/<int:book_id>", methods=["POST"])
def return_book(book_id):
    if "user_id" not in session:
        flash("يجب تسجيل الدخول أولاً", "error")
        return redirect("/")

    user_id = session["user_id"]

    borrowing = Borrowing.query.filter_by(
        
        user_id=session["user_id"],
        book_id=book_id,
        status="borrowed"
    ).first()

    if not borrowing:
        flash("لم يتم استعارة هذا الكتاب", "error")
        return redirect("/user")

    borrowing.status = "avalible"
    borrowing.return_date = date.today()

    borrowing.book.status = "avalible"

    db.session.commit()

    flash("تم إرجاع الكتاب بنجاح", "success")
    return redirect("/user")



@user_bp.route("/user/rate/<int:book_id>", methods=["POST"])
def rate_book(book_id):
    if not user_required():
        return redirect("/")

    user_id = session["user_id"]
    stars = request.form.get("stars")

    borrowed = Borrowing.query.filter_by(
        user_id=user_id,
        book_id=book_id,
    ).first()

    if not borrowed:
        flash("لا يمكن تقييم كتاب غير مستعار", "error")
        return redirect("/user")

   
    if Rating.query.filter_by(
        user_id=user_id,
        book_id=book_id
    ).first():
        flash("تم تقييم هذا الكتاب سابقاً", "error")
        return redirect("/user")

    rating = Rating(
        user_id=user_id,
        book_id=book_id,
        stars=int(stars)
    )

    db.session.add(rating)
    db.session.commit()

    flash("تم إرسال التقييم بنجاح", "success")
    return redirect("/user")