from flask import Blueprint, render_template, request, redirect, flash, session
from models import db
from models.book import Book
from models.category import Category
from models.user import User
from models.admin import Admin
from models.borrowing import Borrowing
from models.rating import Rating



admin_bp = Blueprint("admin", __name__)

def admin_required():
    if "admin_id" not in session:
        flash("غير مصرح لك بالوصول إلى هذه الصفحة", "error")
        return False
    return True


@admin_bp.route("/admin")
def admin_dashboard():
    if not admin_required():
        return redirect("/")

    admin = Admin.query.first() 
    users = User.query.all()
    books = Book.query.all()
    categories = Category.query.all()

    if not users:
        flash("لا يوجد مستخدمون مسجلون", "error")

    return render_template(
        "admin_dashboard.html",
        admin=admin,
        users=users,
        books=books,
        categories=categories
    )


@admin_bp.route("/admin/add_category", methods=["POST"])
def add_category():
    if not admin_required():
        return redirect("/")

    name = request.form.get("name")

    if Category.query.filter_by(name=name).first():
        flash("التصنيف موجود مسبقًا", "error")
        return redirect("/admin")

    db.session.add(Category(name=name))
    db.session.commit()
    flash("تمت إضافة التصنيف بنجاح", "success")
    return redirect("/admin")


@admin_bp.route("/admin/add_book", methods=["POST"])
def add_book():
    if not admin_required():
        return redirect("/")
    book_id = request.form.get("book_id")
    title = request.form.get("title")
    author = request.form.get("author")
    serial = request.form.get("serial_number")
    category_id = request.form.get("category_id")

    if not title or not author or not serial or not category_id:
        flash("يرجى إدخال بيانات صحيحة", "error")
        return redirect("/admin")

    if Book.query.filter_by(title=title).first():
        flash("يرجى تغيير اسم الكتاب", "error")
        return redirect("/admin")
    
    if Book.query.filter_by(book_id=book_id).first():
        flash("يرجى تغيير رقم الكتاب", "error")
        return redirect("/admin")        

    db.session.add(Book(
        book_id=request.form.get("book_id"),
        title=title,
        author=author,
        serial_number=serial,
        category_id=category_id,
        status="avalible",
        admin_id=session["admin_id"]
    ))
    db.session.commit()

    flash("تمت إضافة الكتاب بنجاح", "success")
    return redirect("/admin")


@admin_bp.route("/admin/delete_book/<int:book_id>")
def delete_book(book_id):
    if not admin_required():
        return redirect("/")

    book = Book.query.get_or_404(book_id)

    
    active_borrow = Borrowing.query.filter_by(
        book_id=book_id,
        status="borrowed"
    ).first()

    if active_borrow:
        flash("لا يمكن حذف كتاب مستعار حاليًا", "error")
        return redirect("/admin")

    Rating.query.filter_by(book_id=book_id).delete()

    Borrowing.query.filter_by(book_id=book_id).delete()

    db.session.delete(book)
    db.session.commit()

    flash("تم حذف الكتاب بنجاح", "success")
    return redirect("/admin")

@admin_bp.route("/admin/edit_book", methods=["POST"])
def edit_book():
    if "admin_id" not in session:
        flash("غير مصرح لك بالوصول", "error")
        return redirect("/")

    book_id = request.form.get("book_id")
    new_title = request.form.get("title")
    new_author = request.form.get("author")

    book = Book.query.get(book_id)
    if not book:
        flash("الكتاب غير موجود", "error")
        return redirect("/admin")

   
    duplicate = Book.query.filter(
        Book.title == new_title,
        Book.book_id != book_id
    ).first()

    if duplicate:
        flash("اسم الكتاب موجود مسبقًا", "error")
        return redirect("/admin")

    try:
        book.title = new_title
        book.author = new_author
        db.session.commit()
        flash("تم تحديث الكتاب بنجاح", "success")
    except Exception as e:
        db.session.rollback()
        print(e)
        flash("فشل في التحديث", "error")

    return redirect("/admin")

   
    