from flask import Blueprint, render_template, request, redirect, session, flash, url_for
from models.user import User
from models.admin import Admin
from models import db
import re

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

       
        user = User.query.filter_by(email=email, password=password).first()
        if user:
            session["user_id"] = user.user_id
            return redirect("/user")

        
        admin = Admin.query.filter_by(email=email, password=password).first()
        if admin:
            session["admin_id"] = admin.admin_id
            return redirect("/admin")

        
        flash("بيانات الدخول غير صحيحة", "error")
        return redirect(url_for("auth.login"))

    return render_template("auth.html")



@auth_bp.route("/register", methods=["POST"])
def register():
    name = request.form["name"]
    email = request.form["email"]
    password = request.form["password"]

    
    if not name or not email or not password:
        flash("الرجاء إدخال البيانات صحيحة واكمال الحقول", "error")
        return redirect(url_for("auth.login"))

    
    if not re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', email):
        flash("الرجاء إدخال بريد إلكتروني صالح", "error")
        return redirect(url_for("auth.login"))

    
    if len(password) < 8:
        flash("كلمة المرور يجب أن تكون 8 محارف على الأقل", "error")
        return redirect(url_for("auth.login"))

   
    if User.query.filter_by(email=email).first():
        flash("البريد الإلكتروني مستخدم مسبقًا", "error")
        return redirect(url_for("auth.login"))

    
    db.session.add(User(name=name, email=email, password=password))
    db.session.commit()

    flash("تم إنشاء الحساب بنجاح، يمكنك تسجيل الدخول الآن", "success")
    return redirect(url_for("auth.login"))