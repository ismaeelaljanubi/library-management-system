from . import db
from datetime import date



class Borrowing(db.Model):
    __tablename__ = "borrow"

    borrowing_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.user_id"), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey("book.book_id"), nullable=False)

    borrow_date = db.Column(db.Date, nullable=False)
    return_date = db.Column(db.Date)
    status = db.Column(db.Enum("avalible", "borrowed"), nullable=False)

    book = db.relationship("Book", backref="borrow")