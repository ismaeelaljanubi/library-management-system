from . import db
class Book(db.Model):
    __tablename__ = "book"

    book_id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    author = db.Column(db.String(150), nullable=False)
    serial_number = db.Column(db.String(100), unique=True, nullable=False)
    status = db.Column(db.Enum("avalible", "borrowed"), default="avalible")
    category_id = db.Column(db.Integer, db.ForeignKey("category.category_id"), nullable=False)
    admin_id = db.Column(db.Integer, db.ForeignKey("admin.admin_id"), nullable=False)
    category=db.relationship("Category",backref="books")